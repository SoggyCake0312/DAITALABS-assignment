"""
Configuration for the RAG pipeline.
"""
import os

# --- Paths ---
EMAILS_DIR = os.path.join(os.path.dirname(__file__), "emails")
TEST_QUERIES_PATH = os.path.join(os.path.dirname(__file__), "test_queries.json")
CHROMA_DB_DIR = os.path.join(os.environ.get("TEMP", os.path.dirname(__file__)), "ai-uno-chroma-db")

# --- Embedding Model ---
EMBEDDING_MODEL = "all-MiniLM-L6-v2"

# --- LLM Backend: "openai" or "ollama" ---
LLM_BACKEND = "openai"

# --- OpenAI Config ---
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "YOUR_OPENAI_API_KEY_HERE")
OPENAI_MODEL = "gpt-4o-mini"

# --- Ollama Config ---
OLLAMA_BASE_URL = "http://localhost:11434"
OLLAMA_MODEL = "llama3.2:3b"

# --- Retrieval ---
TOP_K = 5

# --- ChromaDB ---
CHROMA_COLLECTION_NAME = "emails"
