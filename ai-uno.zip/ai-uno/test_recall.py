"""Test retrieval recall on all 100 test queries."""
import json
from src.email_parser import parse_all_emails
from src.chunker import build_all_chunks
from src.indexer import index_chunks, get_embedding_model, get_chroma_client, get_or_create_collection
from src.retriever import retrieve

# Parse, chunk, index
emails = parse_all_emails("emails")
chunks = build_all_chunks(emails)
model = get_embedding_model()

# Use existing index if available
client = get_chroma_client()
collection = get_or_create_collection(client)
if collection.count() < len(chunks):
    collection = index_chunks(chunks, model=model, force_reindex=True)

# Load test queries
with open("test_queries.json", "r", encoding="utf-8") as f:
    data = json.load(f)

# Test recall@5 on answerable queries only
answerable = [q for q in data["queries"] if q["answerable"]]
hits = 0
misses = []

for q in answerable:
    results = retrieve(q["query"], model=model, collection=collection)
    filenames = [r["filename"] for r in results]
    source = q["source_emails"]
    hit = any(s in filenames for s in source)
    if hit:
        hits += 1
    else:
        misses.append((q["id"], q["query"], source, filenames))

print(f"\nRecall@5: {hits}/{len(answerable)} = {hits/len(answerable):.2%}")
print(f"\nMisses ({len(misses)}):")
for qid, query, expected, got in misses:
    print(f"  {qid}: {query}")
    print(f"    Expected: {expected} | Got: {got}")
