"""
Evaluate — run all test queries and compute Recall@5, Answer Accuracy, Hallucination Rate.
"""
import json

import config
from src.retriever import retrieve
from src.generator import generate


# Phrases that indicate the system is declining to answer
DECLINE_PHRASES = [
    "not available",
    "not present",
    "not found",
    "cannot be determined",
    "cannot determine",
    "no information",
    "not mentioned",
    "not specified",
    "not provided",
    "does not contain",
    "don't have",
    "do not have",
    "cannot find",
    "unable to find",
    "unable to determine",
    "no relevant",
    "not in the provided",
    "not included",
    "not explicitly",
    "i cannot answer",
    "i can't answer",
]


def is_decline(answer):
    """Check if the generated answer is a decline/refusal to answer."""
    answer_lower = answer.lower()
    return any(phrase in answer_lower for phrase in DECLINE_PHRASES)


def evaluate(model, collection, backend=None, test_queries_path=None):
    """
    Run evaluation on all test queries.
    
    Returns:
        dict with metrics and per-query details
    """
    if test_queries_path is None:
        test_queries_path = config.TEST_QUERIES_PATH

    with open(test_queries_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    queries = data["queries"]

    # Counters
    answerable_count = 0
    unanswerable_count = 0
    recall_hits = 0
    accuracy_hits = 0
    hallucination_count = 0

    results = []

    for q in queries:
        qid = q["id"]
        query = q["query"]
        answerable = q["answerable"]
        reference = q.get("reference_answer")
        source_emails = q.get("source_emails", [])

        print(f"\n[{qid}] {query}")

        # Retrieve
        retrieved = retrieve(query, model=model, collection=collection)
        retrieved_filenames = [r["filename"] for r in retrieved]

        # Generate
        answer = generate(query, retrieved, backend=backend)
        declined = is_decline(answer)

        print(f"  Retrieved: {retrieved_filenames}")
        print(f"  Answer: {answer[:120]}{'...' if len(answer) > 120 else ''}")
        print(f"  Declined: {declined}")

        result = {
            "id": qid,
            "query": query,
            "answerable": answerable,
            "reference_answer": reference,
            "source_emails": source_emails,
            "retrieved_filenames": retrieved_filenames,
            "answer": answer,
            "declined": declined,
        }

        if answerable:
            answerable_count += 1

            # Recall@5: is the source email in top-5?
            recall_hit = any(se in retrieved_filenames for se in source_emails)
            if recall_hit:
                recall_hits += 1
            result["recall_hit"] = recall_hit

            # Answer accuracy: does the answer contain the reference?
            accuracy_hit = False
            if reference and not declined:
                accuracy_hit = reference.lower() in answer.lower()
            if accuracy_hit:
                accuracy_hits += 1
            result["accuracy_hit"] = accuracy_hit

            print(f"  Recall hit: {recall_hit} | Accuracy hit: {accuracy_hit}")
        else:
            unanswerable_count += 1

            # Hallucination: did the system give a confident answer instead of declining?
            hallucinated = not declined
            if hallucinated:
                hallucination_count += 1
            result["hallucinated"] = hallucinated

            print(f"  Hallucinated: {hallucinated}")

        results.append(result)

    # Compute metrics
    recall_at_5 = recall_hits / answerable_count if answerable_count > 0 else 0
    answer_accuracy = accuracy_hits / answerable_count if answerable_count > 0 else 0
    hallucination_rate = hallucination_count / unanswerable_count if unanswerable_count > 0 else 0

    metrics = {
        "recall_at_5": recall_at_5,
        "answer_accuracy": answer_accuracy,
        "hallucination_rate": hallucination_rate,
        "answerable_count": answerable_count,
        "unanswerable_count": unanswerable_count,
        "recall_hits": recall_hits,
        "accuracy_hits": accuracy_hits,
        "hallucination_count": hallucination_count,
    }

    print("\n" + "=" * 60)
    print("EVALUATION RESULTS")
    print("=" * 60)
    print(f"  Recall@5:           {recall_at_5:.2%} ({recall_hits}/{answerable_count})  Target: >= 80%")
    print(f"  Answer Accuracy:    {answer_accuracy:.2%} ({accuracy_hits}/{answerable_count})  Target: >= 75%")
    print(f"  Hallucination Rate: {hallucination_rate:.2%} ({hallucination_count}/{unanswerable_count})  Target: <= 20%")
    print("=" * 60)

    return {"metrics": metrics, "results": results}
