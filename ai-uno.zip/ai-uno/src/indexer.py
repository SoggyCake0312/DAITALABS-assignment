"""
Indexer — embeds email chunks and stores them in ChromaDB.
"""
import chromadb
from sentence_transformers import SentenceTransformer

import config


def get_embedding_model():
    """Load the sentence-transformers embedding model."""
    return SentenceTransformer(config.EMBEDDING_MODEL)


def get_chroma_client():
    """Get a persistent ChromaDB client."""
    return chromadb.PersistentClient(path=config.CHROMA_DB_DIR)


def get_or_create_collection(client):
    """Get or create the emails collection."""
    return client.get_or_create_collection(
        name=config.CHROMA_COLLECTION_NAME,
        metadata={"hnsw:space": "cosine"},
    )


def index_chunks(chunks, model=None, force_reindex=False):
    """
    Index all chunks into ChromaDB.
    
    Args:
        chunks: list of (filename, chunk_text, metadata) tuples
        model: SentenceTransformer model (loaded if None)
        force_reindex: if True, delete and recreate the collection
    """
    if model is None:
        model = get_embedding_model()

    client = get_chroma_client()

    if force_reindex:
        try:
            client.delete_collection(config.CHROMA_COLLECTION_NAME)
        except Exception:
            pass

    collection = get_or_create_collection(client)

    # Skip if already indexed
    if collection.count() >= len(chunks) and not force_reindex:
        print(f"Collection already has {collection.count()} documents. Skipping indexing.")
        return collection

    # Prepare batch data
    ids = []
    documents = []
    metadatas = []
    embeddings = []

    print(f"Embedding {len(chunks)} email chunks...")
    texts = [chunk_text for _, chunk_text, _ in chunks]
    all_embeddings = model.encode(texts, show_progress_bar=True, convert_to_numpy=True)

    for i, (filename, chunk_text, metadata) in enumerate(chunks):
        ids.append(filename)
        documents.append(chunk_text)
        metadatas.append(metadata)
        embeddings.append(all_embeddings[i].tolist())

    # Upsert in batches (ChromaDB has a batch limit)
    batch_size = 50
    for start in range(0, len(ids), batch_size):
        end = start + batch_size
        collection.upsert(
            ids=ids[start:end],
            documents=documents[start:end],
            metadatas=metadatas[start:end],
            embeddings=embeddings[start:end],
        )

    print(f"Indexed {collection.count()} documents into ChromaDB.")
    return collection
