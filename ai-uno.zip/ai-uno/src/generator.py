"""
Generator — uses an LLM to answer queries based on retrieved email context.
Supports OpenAI and Ollama backends, switchable via config.LLM_BACKEND.
"""
import json

import requests
from openai import OpenAI

import config


SYSTEM_PROMPT = """You are a precise email assistant. Answer the user's question using ONLY the provided email context below.

Rules:
1. Base your answer strictly on the email context provided. Do not use any outside knowledge.
2. Be concise and direct. Give the specific answer requested (a name, email address, subject, etc.).
3. If the information needed to answer the question is NOT present in the provided emails, respond with exactly: "The requested information is not available in the provided emails."
4. Do not guess, infer beyond what's written, or fabricate any information.
5. When asked about email addresses or domains, extract them exactly as they appear in the email headers."""


def _build_prompt(query, retrieved_docs):
    """Build the user prompt with retrieved context."""
    context_parts = []
    for i, doc in enumerate(retrieved_docs, 1):
        context_parts.append(f"--- Email {i} ---\n{doc['document']}\n")

    context = "\n".join(context_parts)
    return f"Email Context:\n{context}\n\nQuestion: {query}"


def generate_openai(query, retrieved_docs):
    """Generate answer using OpenAI API."""
    client = OpenAI(api_key=config.OPENAI_API_KEY)

    user_prompt = _build_prompt(query, retrieved_docs)

    response = client.chat.completions.create(
        model=config.OPENAI_MODEL,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0,
        max_tokens=256,
    )

    return response.choices[0].message.content.strip()


def generate_ollama(query, retrieved_docs):
    """Generate answer using Ollama local API."""
    user_prompt = _build_prompt(query, retrieved_docs)

    full_prompt = f"{SYSTEM_PROMPT}\n\n{user_prompt}"

    payload = {
        "model": config.OLLAMA_MODEL,
        "prompt": full_prompt,
        "stream": False,
        "options": {
            "temperature": 0,
            "num_predict": 256,
        },
    }

    response = requests.post(
        f"{config.OLLAMA_BASE_URL}/api/generate",
        json=payload,
        timeout=600,
    )
    response.raise_for_status()
    return response.json()["response"].strip()


def generate(query, retrieved_docs, backend=None):
    """
    Generate an answer using the configured LLM backend.
    
    Args:
        query: the user question
        retrieved_docs: list of retrieved document dicts from retriever
        backend: "openai" or "ollama" (defaults to config.LLM_BACKEND)
    """
    if backend is None:
        backend = config.LLM_BACKEND

    if backend == "openai":
        return generate_openai(query, retrieved_docs)
    elif backend == "ollama":
        return generate_ollama(query, retrieved_docs)
    else:
        raise ValueError(f"Unknown LLM backend: {backend}")
