"""
Email parser — robust extraction of headers and body from raw email text files.
Handles noisy cases: missing headers, swapped order, duplicates, encoding artifacts.
"""
import os
import re


def parse_email(filepath):
    """
    Parse a single email file and return a structured dict.
    Best-effort: missing fields become None; no email is ever skipped.
    """
    with open(filepath, "r", encoding="utf-8", errors="replace") as f:
        raw_text = f.read()

    filename = os.path.basename(filepath)

    # Extract headers via regex (order-independent)
    subject = _extract_header(raw_text, "Subject")
    from_field = _extract_header(raw_text, "From")
    to_field = _extract_header(raw_text, "To")

    # Parse name and email from "Name <email>" format
    from_name, from_email = _parse_name_email(from_field)
    to_name, to_email = _parse_name_email(to_field)

    # If From header is missing, try to extract sender from sign-off
    if from_name is None:
        from_name = _extract_sender_from_signoff(raw_text)

    # Extract body (everything after the header block + blank line)
    body = _extract_body(raw_text)

    return {
        "filename": filename,
        "filepath": filepath,
        "subject": subject,
        "from_name": from_name,
        "from_email": from_email,
        "to_name": to_name,
        "to_email": to_email,
        "body": body,
        "raw_text": raw_text,
    }


def parse_all_emails(emails_dir):
    """Parse all .txt files in the emails directory."""
    emails = []
    for fname in sorted(os.listdir(emails_dir)):
        if fname.endswith(".txt"):
            filepath = os.path.join(emails_dir, fname)
            emails.append(parse_email(filepath))
    return emails


def _extract_header(text, header_name):
    """
    Extract the first occurrence of a header field.
    Handles duplicate headers by taking the first match.
    """
    pattern = rf"^{re.escape(header_name)}:\s*(.+)$"
    match = re.search(pattern, text, re.MULTILINE | re.IGNORECASE)
    if match:
        return match.group(1).strip()
    return None


def _parse_name_email(field_value):
    """
    Parse 'Full Name <email@domain.com>' into (name, email).
    Returns (None, None) if field_value is None or unparseable.
    """
    if not field_value:
        return None, None

    # Try "Name <email>" pattern
    match = re.match(r"(.+?)\s*<([^>]+)>", field_value)
    if match:
        return match.group(1).strip(), match.group(2).strip()

    # Try bare email
    match = re.match(r"([^\s@]+@[^\s@]+\.[^\s@]+)", field_value)
    if match:
        return None, match.group(1).strip()

    # Return the raw value as name
    return field_value.strip(), None


def _extract_sender_from_signoff(text):
    """
    Fallback: extract sender name from common email sign-off patterns.
    Matches lines like:
      Thanks,\nJohn Doe
      Best,\nJane Smith
      Cheers,\nMia Harris
    """
    # Look for common sign-off words followed by a name on the next line
    pattern = r"(?:Thanks|Thank you|Best|Best regards|Regards|Cheers|Sincerely|With appreciation|Warm regards),?\s*\n\s*([A-Z][a-z]+ [A-Z][a-z]+)"
    match = re.search(pattern, text)
    if match:
        return match.group(1).strip()
    return None


def _extract_body(text):
    """
    Extract the email body — everything after the header block.
    The header block ends at the first blank line after headers.
    """
    # Split on the first blank line that follows header-like lines
    lines = text.split("\n")
    body_start = 0
    in_headers = True

    for i, line in enumerate(lines):
        if in_headers:
            stripped = line.strip()
            # A header line matches "Key: value" or is empty
            if stripped == "":
                # Blank line after headers = body starts next line
                body_start = i + 1
                in_headers = False
            elif not re.match(r"^(Subject|From|To|Cc|Bcc|Date|Reply-To):", stripped, re.IGNORECASE):
                # Non-header, non-blank line while still in "header zone"
                # Could be a continuation or the body started without blank line
                body_start = i
                in_headers = False

    return "\n".join(lines[body_start:]).strip()
