"""
Retriever — hybrid retrieval combining semantic search with keyword-based
metadata matching. Semantic search alone struggles with metadata-specific
queries like "What is X's email address?" — keyword boosting fixes this.
"""
import re

from sentence_transformers import SentenceTransformer

import config
from src.indexer import get_chroma_client, get_or_create_collection


def _extract_person_names(query):
    """Extract likely person names (capitalized two-word sequences) from a query."""
    # Match sequences like "Felix Jordan", "Tara Woods", etc.
    names = re.findall(r"\b([A-Z][a-z]+ [A-Z][a-z]+)\b", query)
    return names


def _keyword_search(collection, query, top_k):
    """
    Search ChromaDB metadata for person names mentioned in the query.
    Returns matching documents ranked by how many name fields match.
    """
    names = _extract_person_names(query)
    if not names:
        return []

    # Get all documents from collection
    all_docs = collection.get(include=["documents", "metadatas"])

    scored = []
    for i, doc_id in enumerate(all_docs["ids"]):
        metadata = all_docs["metadatas"][i]
        document = all_docs["documents"][i]
        score = 0

        for name in names:
            name_lower = name.lower()
            # Check metadata fields
            if name_lower in (metadata.get("from_name") or "").lower():
                score += 2
            if name_lower in (metadata.get("to_name") or "").lower():
                score += 2
            # Check full document text as fallback
            if name_lower in document.lower():
                score += 1

        if score > 0:
            scored.append({
                "filename": doc_id,
                "document": document,
                "distance": 1.0 - (score / (len(names) * 5)),  # Normalize to 0-1 range
                "metadata": metadata,
                "keyword_score": score,
            })

    # Sort by score descending
    scored.sort(key=lambda x: x["keyword_score"], reverse=True)
    return scored[:top_k]


def retrieve(query, model=None, collection=None, top_k=None):
    """
    Hybrid retrieval: merge semantic search results with keyword-based
    metadata matches, re-ranked by a combined score.
    """
    if top_k is None:
        top_k = config.TOP_K

    if model is None:
        model = SentenceTransformer(config.EMBEDDING_MODEL)

    if collection is None:
        client = get_chroma_client()
        collection = get_or_create_collection(client)

    # --- Semantic search ---
    query_embedding = model.encode(query, convert_to_numpy=True).tolist()
    sem_results = collection.query(
        query_embeddings=[query_embedding],
        n_results=top_k * 2,  # Fetch more for re-ranking
        include=["documents", "metadatas", "distances"],
    )

    semantic_docs = {}
    for i in range(len(sem_results["ids"][0])):
        fid = sem_results["ids"][0][i]
        semantic_docs[fid] = {
            "filename": fid,
            "document": sem_results["documents"][0][i],
            "distance": sem_results["distances"][0][i],
            "metadata": sem_results["metadatas"][0][i],
        }

    # --- Keyword search ---
    keyword_docs = _keyword_search(collection, query, top_k * 2)
    keyword_map = {d["filename"]: d for d in keyword_docs}

    # --- Merge and re-rank ---
    all_candidates = set(semantic_docs.keys()) | set(keyword_map.keys())
    merged = []

    for fid in all_candidates:
        sem = semantic_docs.get(fid)
        kw = keyword_map.get(fid)

        # Semantic score: convert cosine distance to similarity (0 to 1)
        sem_score = (1 - sem["distance"]) if sem else 0

        # Keyword score: normalized
        kw_score = (kw["keyword_score"] / 5) if kw else 0  # max ~1.0

        # Combined score (weighted)
        combined = 0.6 * sem_score + 0.4 * kw_score

        doc = sem or kw
        merged.append({
            "filename": fid,
            "document": doc["document"],
            "distance": 1 - combined,  # Convert back to distance for consistency
            "metadata": doc["metadata"],
        })

    # Sort by combined score (lower distance = better)
    merged.sort(key=lambda x: x["distance"])

    return merged[:top_k]
