"""
Chunker — builds the text representation of each email for embedding.
One email = one chunk. Raw text with metadata placed prominently.
"""


def build_chunk(parsed_email):
    """
    Build a single chunk string from a parsed email dict.
    Metadata is placed at the top so it's prominent in the embedding.
    """
    parts = []

    parts.append(f"Filename: {parsed_email['filename']}")

    if parsed_email["subject"]:
        parts.append(f"Subject: {parsed_email['subject']}")

    if parsed_email["from_name"] and parsed_email["from_email"]:
        parts.append(f"From: {parsed_email['from_name']} <{parsed_email['from_email']}>")
    elif parsed_email["from_name"]:
        parts.append(f"From: {parsed_email['from_name']}")
    elif parsed_email["from_email"]:
        parts.append(f"From: {parsed_email['from_email']}")

    if parsed_email["to_name"] and parsed_email["to_email"]:
        parts.append(f"To: {parsed_email['to_name']} <{parsed_email['to_email']}>")
    elif parsed_email["to_name"]:
        parts.append(f"To: {parsed_email['to_name']}")
    elif parsed_email["to_email"]:
        parts.append(f"To: {parsed_email['to_email']}")

    parts.append("")  # blank line separator
    parts.append(parsed_email.get("body", ""))

    return "\n".join(parts)


def build_all_chunks(parsed_emails):
    """Build chunks for all parsed emails. Returns list of (filename, chunk_text, metadata)."""
    chunks = []
    for email in parsed_emails:
        chunk_text = build_chunk(email)
        metadata = {
            "filename": email["filename"],
            "subject": email.get("subject") or "",
            "from_name": email.get("from_name") or "",
            "from_email": email.get("from_email") or "",
            "to_name": email.get("to_name") or "",
            "to_email": email.get("to_email") or "",
        }
        chunks.append((email["filename"], chunk_text, metadata))
    return chunks
