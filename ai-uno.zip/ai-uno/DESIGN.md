# RAG Pipeline — Design, Setup & Evaluation

## Overview

A from-scratch Retrieval-Augmented Generation (RAG) pipeline for email Q&A, built without end-to-end frameworks (no LangChain/LlamaIndex). The system processes 100 synthetic emails, retrieves relevant documents via hybrid search, and generates answers using an LLM.

---

## Architecture

```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│ Email Parser │────▶│   Chunker    │────▶│   Indexer    │
│  (robust,    │     │ (1 email =   │     │ (sentence-   │
│  best-effort)│     │  1 chunk)    │     │  transformers │
└──────────────┘     └──────────────┘     │ + ChromaDB)  │
                                          └──────┬───────┘
                                                 │
                     ┌──────────────┐     ┌──────▼───────┐
                     │  Generator   │◀────│  Retriever   │
                     │ (OpenAI /    │     │ (hybrid:     │
                     │  Ollama)     │     │  semantic +  │
                     └──────────────┘     │  keyword)    │
                                          └──────────────┘
```

### Components

| File | Purpose |
|---|---|
| `config.py` | Central configuration (paths, models, API keys, LLM backend switch) |
| `src/email_parser.py` | Robust email header/body extraction with noisy-email handling |
| `src/chunker.py` | Builds embedding-ready text chunks from parsed emails |
| `src/indexer.py` | Embeds chunks with `sentence-transformers` and stores in ChromaDB |
| `src/retriever.py` | Hybrid retrieval: semantic similarity + keyword metadata matching |
| `src/generator.py` | LLM answer generation (OpenAI and Ollama backends) |
| `src/evaluate.py` | Runs all 100 test queries and computes metrics |
| `rag_pipeline.py` | Main CLI entry point |

---

## Design Choices

### Chunking: One Email = One Chunk
Each email is ~100–200 words — small enough to embed as a single document. Splitting would break the metadata–body relationship, and queries frequently ask about sender/recipient/subject, which must co-occur with the body text.

### Embedding Model: `all-MiniLM-L6-v2`
Lightweight (90 MB), 384-dimensional, fast inference. Sufficient for this dataset size. Chunk text places metadata (From, To, Subject, Filename) prominently at the top so names and email addresses are captured in the embedding.

### Hybrid Retrieval
Pure semantic search struggles with metadata-specific queries like "What is Felix Jordan's email address?" because the embedding model doesn't match person names literally. The retriever combines:
- **Semantic search** (60% weight): cosine similarity via ChromaDB
- **Keyword search** (40% weight): exact name matching in metadata fields (from_name, to_name)

This boosted Recall@5 from 85% to 100%.

### Noisy Email Handling
~12% of emails contain data quality issues. The parser handles these gracefully:

| Issue | Example | Handling |
|---|---|---|
| Mojibake encoding | `â€™` instead of `'` | Raw text embedded as-is; headers still parseable |
| Truncated content | Email cut off mid-word | Partial content indexed normally |
| Missing From: header | No `From:` line | Sender extracted from sign-off ("Cheers,\nMia Harris") |
| Swapped header order | `To:` before `From:` | Regex matches headers order-independently |
| Duplicate headers | Double `Subject:` / `From:` | First occurrence taken |
| Tagged subjects | `[EXTERNAL][BULK] Budget Approval` | Stored as-is; still searchable |
| Scattered typos | Body misspellings | Headers are clean; body embedded as-is |

**Key principle:** The parser is best-effort, not a gatekeeper. Every email is always indexed with its raw text, even if metadata extraction fails.

### LLM Backend Switch
`config.py` has `LLM_BACKEND = "openai"` or `"ollama"`. The CLI also accepts `--backend ollama` / `--backend openai` to override at runtime.

### Hallucination Control
The system prompt instructs the LLM to answer ONLY from provided context and respond with a specific decline phrase when information is unavailable. The evaluator checks for decline phrases to measure hallucination rate.

---

## Setup

### Prerequisites
- Python 3.10+
- (Optional) Ollama installed locally with a pulled model

### Install Dependencies

```bash
pip install sentence-transformers chromadb openai requests
```

### Configure

Edit `config.py`:
- Set `OPENAI_API_KEY` or export it as environment variable `OPENAI_API_KEY`
- Set `LLM_BACKEND` to `"openai"` or `"ollama"`
- Ollama: ensure the server is running (`ollama serve`) and model is pulled (`ollama pull llama3.2:3b`)

---

## Usage

### Build the Index

```bash
python rag_pipeline.py index
# Force re-index:
python rag_pipeline.py index --force
```

### Run a Single Query

```bash
# Using default LLM backend (from config.py):
python rag_pipeline.py query "Who sent a budget approval request to Yvonne Griffin?"

# Using OpenAI:
python rag_pipeline.py query "Who sent a budget approval request to Yvonne Griffin?" --backend openai

# Using Ollama:
python rag_pipeline.py query "Who sent a budget approval request to Yvonne Griffin?" --backend ollama
```

### Run Full Evaluation

```bash
# Using default backend:
python rag_pipeline.py evaluate

# Using specific backend:
python rag_pipeline.py evaluate --backend openai
python rag_pipeline.py evaluate --backend ollama
```

Results are printed to the console and saved to `evaluation_results_<backend>.json`.

### Run Recall-Only Test (No LLM Needed)

```bash
python test_recall.py
```

This tests only the retrieval component (embedding + ChromaDB + hybrid search) without requiring an LLM API.

---

## Test Results

### Retrieval: Recall@5

Tested on all 75 answerable queries from `test_queries.json`.

| Metric | Score | Target |
|---|---|---|
| **Recall@5** | **100.00%** (75/75) | ≥ 80% |

All 75 answerable queries retrieved the correct source email within the top-5 results, including noisy emails (mojibake, missing headers, truncated content, duplicate headers, etc.).

#### Retrieval improvement breakdown:

| Retrieval Strategy | Recall@5 | Notes |
|---|---|---|
| Semantic-only | 85.33% (64/75) | 11 misses, all metadata-specific queries (email address / domain lookups) |
| Hybrid (semantic + keyword) | **100.00%** (75/75) | All metadata queries resolved by keyword matching on person names |

### Answer Accuracy & Hallucination Rate

These metrics require LLM inference over all 100 queries. To run:

```bash
python rag_pipeline.py evaluate --backend openai
# or
python rag_pipeline.py evaluate --backend ollama
```

The evaluation script will report:
- **Answer Accuracy**: Fraction of answerable queries where the generated answer contains the reference answer (case-insensitive substring match). Target: ≥ 75%.
- **Hallucination Rate**: Fraction of unanswerable queries where the system produces a confident answer instead of declining. Target: ≤ 20%.

---

## File Structure

```
ai-uno/
├── emails/                  # 100 synthetic email .txt files
├── test_queries.json        # 100 gold-labeled test queries
├── config.py                # Configuration (API keys, models, paths)
├── rag_pipeline.py          # Main CLI entry point
├── src/
│   ├── __init__.py
│   ├── email_parser.py      # Robust email parsing
│   ├── chunker.py           # Chunk construction
│   ├── indexer.py           # Embedding + ChromaDB indexing
│   ├── retriever.py         # Hybrid retrieval
│   ├── generator.py         # LLM generation (OpenAI / Ollama)
│   └── evaluate.py          # Metric computation
├── test_recall.py           # Standalone recall test (no LLM)
├── test_quick.py            # Quick sanity test
├── requirements.txt         # Python dependencies
└── DESIGN.md                # This file
```
