"""Quick test script for the RAG pipeline."""
from src.email_parser import parse_all_emails
from src.chunker import build_all_chunks
from src.indexer import index_chunks, get_embedding_model
from src.retriever import retrieve

# Parse and chunk
emails = parse_all_emails("emails")
chunks = build_all_chunks(emails)
print(f"Parsed {len(emails)} emails, built {len(chunks)} chunks")

# Index
model = get_embedding_model()
collection = index_chunks(chunks, model=model, force_reindex=True)

# Test retrieval
test_queries = [
    ("Who sent a budget approval request to Yvonne Griffin?", "email_003.txt"),
    ("What is the email address of Felix Jordan?", "email_003.txt"),
    ("Who sent a client feedback email to Sean Cox?", "email_038.txt"),  # noisy: missing From header
    ("Who sent a performance review email to Blake Simmons?", "email_051.txt"),  # noisy: swapped headers
    ("Who sent a vendor proposal to Logan West?", "email_072.txt"),  # noisy: duplicate headers
]

for query, expected in test_queries:
    results = retrieve(query, model=model, collection=collection)
    filenames = [r["filename"] for r in results]
    hit = expected in filenames
    print(f"\n{'HIT' if hit else 'MISS'} | Q: {query}")
    print(f"  Expected: {expected} | Got: {filenames}")
