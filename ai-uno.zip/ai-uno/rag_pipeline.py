"""
RAG Pipeline — main entry point.

Usage:
    # Index emails and run a single query (OpenAI):
    python rag_pipeline.py query "Who sent a budget approval request to Yvonne Griffin?"

    # Use Ollama instead:
    python rag_pipeline.py query "Who sent a budget approval request to Yvonne Griffin?" --backend ollama

    # Run full evaluation:
    python rag_pipeline.py evaluate

    # Run evaluation with Ollama:
    python rag_pipeline.py evaluate --backend ollama

    # Force re-index:
    python rag_pipeline.py index --force
"""
import argparse
import json
import sys

import config
from src.email_parser import parse_all_emails
from src.chunker import build_all_chunks
from src.indexer import index_chunks, get_embedding_model, get_chroma_client, get_or_create_collection
from src.retriever import retrieve
from src.generator import generate
from src.evaluate import evaluate


def build_index(force=False):
    """Parse emails, build chunks, embed, and store in ChromaDB."""
    print("Parsing emails...")
    emails = parse_all_emails(config.EMAILS_DIR)
    print(f"Parsed {len(emails)} emails.")

    print("Building chunks...")
    chunks = build_all_chunks(emails)
    print(f"Built {len(chunks)} chunks.")

    print("Loading embedding model...")
    model = get_embedding_model()

    print("Indexing into ChromaDB...")
    collection = index_chunks(chunks, model=model, force_reindex=force)

    return model, collection


def run_query(query, backend=None):
    """Run a single query through the full RAG pipeline."""
    model, collection = build_index()

    print(f"\nQuery: {query}")
    print("-" * 40)

    retrieved = retrieve(query, model=model, collection=collection)

    print("Retrieved emails:")
    for i, r in enumerate(retrieved, 1):
        print(f"  {i}. {r['filename']} (distance: {r['distance']:.4f})")

    answer = generate(query, retrieved, backend=backend)
    print(f"\nAnswer: {answer}")

    return answer


def run_evaluation(backend=None):
    """Run full evaluation on all test queries."""
    model, collection = build_index()
    results = evaluate(model, collection, backend=backend)

    # Save detailed results
    output_path = f"evaluation_results_{backend or config.LLM_BACKEND}.json"
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"\nDetailed results saved to {output_path}")

    return results


def main():
    parser = argparse.ArgumentParser(description="RAG Pipeline for Email Q&A")
    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # Index command
    index_parser = subparsers.add_parser("index", help="Build/rebuild the index")
    index_parser.add_argument("--force", action="store_true", help="Force re-index")

    # Query command
    query_parser = subparsers.add_parser("query", help="Run a single query")
    query_parser.add_argument("question", type=str, help="The question to ask")
    query_parser.add_argument("--backend", choices=["openai", "ollama"], default=None,
                              help="LLM backend (default: from config)")

    # Evaluate command
    eval_parser = subparsers.add_parser("evaluate", help="Run full evaluation")
    eval_parser.add_argument("--backend", choices=["openai", "ollama"], default=None,
                             help="LLM backend (default: from config)")

    args = parser.parse_args()

    if args.command == "index":
        build_index(force=args.force)
    elif args.command == "query":
        run_query(args.question, backend=args.backend)
    elif args.command == "evaluate":
        run_evaluation(backend=args.backend)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
